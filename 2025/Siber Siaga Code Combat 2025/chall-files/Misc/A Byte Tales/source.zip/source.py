from modules.art import banner,congrats_banner, exit_banner, seperator

def intro():
    text = "You stand before a path of binary lights, glowing faintly."
    print(seperator(text) + "\n" + text + "\n" + seperator(text))
    print("Do you wish to:")
    print(" A) Follow the path")
    print(" B) Walk out into the unknown")
    choice = input("Choice: ").strip().upper()
    if choice == "A":
        stage1()
    elif choice == "B":
        alt_path()
    else:
        print("Invalid. The tale ends.")
        exit()

def alt_path():
    alt_text="You step away from the path..."
    print(seperator(alt_text)+"\n"+alt_text+"\n"+seperator(alt_text))
    print("Is this what you really wish for?:")
    choice = input("A)Yes\nB)No\nChoice:").strip().upper()
    if choice == "B":
        print(banner)
        print("Then let's start all over again! :)")
        intro()
    if choice== "A":
        print("You dare go against my story? You shall be punished!")
        gameover()
    else: 
        jail()

def jail():
    banned = ["import", "print", "locals", "class", "base", "subclasses", "globals", "exec", "eval", "os", "sys", "system", "clear", "exit"]
    try:
        for i in range(3):
            cmd = input("Story: ")
            if any(b in cmd for b in banned):
                print("What are you trying to do?")
                break
            else:
                eval(cmd)
    except:
        print("Are you trying to ruin the story?")
    gameover()

def stage1():
    stage1 = "Stage 1: You walk deeper into the glowing path..."
    print(seperator(stage1)+"\n"+stage1+"\n"+seperator(stage1)+"\nA fork appears:")
    print(" A) Left (faint hum)")
    print(" B) Right (silent)")
    choice = input("Choice: ").strip().upper()
    if choice == "A": stage2()
    else: alt_path()

def stage2():
    stage2 = "Stage 2: A byte-sized creature blocks your way."
    print(seperator(stage2)+"\n"+stage2+"\n"+seperator(stage2))
    print(" A) Speak to it")
    print(" B) Ignore it and move on")
    choice = input("Choice: ").strip().upper()
    if choice == "A": stage3()
    else: alt_path()

def stage3():
    stage3 = "Stage 3: The path glows brighter, almost blinding."
    print(seperator(stage3)+"\n"+stage3+"\n"+seperator(stage3))
    print(" A) Shield your eyes and continue")
    print(" B) Turn back")
    choice = input("Choice: ").strip().upper()
    if choice == "A": stage4()
    else: alt_path()

def stage4():
    stage4 = "Stage 4: You find a riddle written in binary runes."
    print(seperator(stage4)+"\n"+stage4+"\n"+seperator(stage4))
    print(" A) Try to solve it")
    print(" B) Smash the runes apart")
    choice = input("Choice: ").strip().upper()
    if choice == "A": stage5()
    else: alt_path()

def stage5():
    stage5 = "Stage 5: The final gate shimmers before you..."
    print(seperator(stage5)+"\n"+stage5+"\n"+seperator(stage5))
    print(" A) Enter the gate")
    print(" B) Refuse and step aside")
    choice = input("Choice: ").strip().upper()
    if choice == "A":
        congrats = "✨ Congratulations! You’ve reached the happy ending of A Byte Tales ✨"
        print(congrats_banner+"\n"+seperator(congrats)+"\n"+congrats+"\n"+seperator(congrats))
        exit()
    else:
        alt_path()

def gameover():
    print(exit_banner)
    exit()

if __name__ == "__main__":
    print(banner)
    intro()