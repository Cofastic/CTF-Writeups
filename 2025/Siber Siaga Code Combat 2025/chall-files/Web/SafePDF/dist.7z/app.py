from flask import Flask, request, send_file, render_template_string
from weasyprint import HTML
import urllib.parse
import io
import sys
import pathlib

app = Flask(__name__)
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent / "app" / "vendor"))

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html>
<head>
    <title>Safe PDF</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
        .container { background: #f5f5f5; padding: 20px; border-radius: 10px; }
        input[type="url"] { width: 500px; padding: 10px; margin: 10px 0; }
        button { padding: 10px 20px; background: #007cba; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #005a87; }
        .result { margin-top: 20px; padding: 10px; background: white; border-radius: 5px; }
        .error { background: #ffebee; color: #c62828; }
    </style>
</head>
<body>
    <div class="container">
        <h1>PDF Converter</h1>
        <p>Enter a URL to convert it to PDF!</p>
        
        <form method="POST">
            <label for="url">URL:</label><br>
            <input type="url" id="url" name="url" placeholder="https://example.com" required>
            <button type="submit">Convert!</button>
        </form>

        {% if error %}
        <div class="result error">
            <h3>Error:</h3>
            <p>{{ error }}</p>
        </div>
        {% endif %}
    </div>
</body>
</html>
'''

def is_valid_url(u: str) -> bool:
    try:
        p = urllib.parse.urlparse(u)
        if p.scheme not in ("http", "https"):
            return False
        if not p.netloc:
            return False
        # optional stricter check:
        try:
            import validators
            return validators.url(u)
        except Exception:
            return True
    except Exception:
        return False

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        url = request.form.get("url").strip()
        if not url:
            return render_template_string(HTML_TEMPLATE, error="Please provide a URL")

        if not is_valid_url(url):
            return render_template_string(HTML_TEMPLATE, error="Invalid or unsupported URL scheme")
        
        doc = HTML(url=url)
        pdf = doc.write_pdf()
        
        bio = io.BytesIO(pdf)
        bio.seek(0)

        send_kwargs = {"as_attachment": True, "mimetype": "application/pdf"}
        try:
            send_kwargs["download_name"] = "download.pdf"
            return send_file(bio, **send_kwargs)
        except TypeError:
            send_kwargs.pop("download_name", None)
            send_kwargs["attachment_filename"] = "download.pdf"
            return send_file(bio, **send_kwargs)

    return render_template_string(HTML_TEMPLATE)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=1337)
