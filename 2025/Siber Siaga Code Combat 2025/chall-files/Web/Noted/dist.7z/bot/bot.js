const puppeteer = require("puppeteer");

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function visit(input, creds) {
	let browser;

	const baseUrl = "http://localhost:3000";
	const flag = process.env.FLAG;

	try {

		const url = input;

		if (!url.startsWith('http://') && !url.startsWith('https://')) {
            throw new Error('Invalid URL format. Please use http:// or https:// URLs only.');
        }

		browser = await puppeteer.launch({
			headless: true,
			executablePath: '/usr/bin/google-chrome-stable',
			args: [
				"--no-sandbox",
				"--disable-setuid-sandbox",
				"--js-flags=--noexpose_wasm,--jitless",
			],
		});

		let page = await browser.newPage();

		await page.setCookie({
			name: "flag",
			value: flag,
			domain: "localhost",
			secure: false,
			httpOnly: false,
		});

		await page.goto(`${baseUrl}/login`, { timeout: 5000, waitUntil: 'domcontentloaded' });
		await sleep(1000);

		await page.type('input[name="username"]', creds.username);
        await page.type('input[name="password"]', creds.password);
        await page.click('button[type="submit"]');

        await sleep(2000);

		await page.goto(url, { timeout: 5000, waitUntil: 'domcontentloaded'});

		await sleep(3000);

	} catch (err) {
		console.log(err);
		throw new Error(`Error visiting URL: ${err.message}`);
	} finally {
		if (browser) await browser.close();
	}
}

module.exports = { visit };