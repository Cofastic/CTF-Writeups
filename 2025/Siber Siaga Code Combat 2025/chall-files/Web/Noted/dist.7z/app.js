const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const { visit } = require('./bot/bot');

const app = express();
const port = 3000;

const secretKey = crypto.randomBytes(32).toString('hex');

const reportLimiter = rateLimit({
	windowMs: 60 * 1000,
	max: 5
});

const db = new sqlite3.Database('notes.db', (err) => {
	if (err) {
		console.log("Failed:", err.message);
		process.exit(1);
	} else {
		console.log("Database opened successfully")
	}
});

db.serialize(() => {
	db.run(`CREATE TABLE IF NOT EXISTS users (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		username TEXT UNIQUE NOT NULL,
		password TEXT NOT NULL
	)`);

	db.run(`CREATE TABLE IF NOT EXISTS notes (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		user_note_id INTEGER NOT NULL,
		user_id INTEGER NOT NULL,
		content TEXT NOT NULL,
		UNIQUE(user_id, user_note_id),
		FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
	)`);
		
	const server = app.listen(port, '0.0.0.0', () => {
		console.log(`Server running at http://0.0.0.0:${port}`);
	});
			
});

function shutdown(signal) {
	console.log(`Received ${signal}. Cleaning up...`);
	db.close(() => process.exit(0));
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

app.use('/static', express.static(path.join(__dirname, 'node_modules/dompurify/dist')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
	store: new SQLiteStore({
		db: 'sessions.sqlite',
		dir: './',
		concurrentDB: false
	}),
	secret: secretKey,
	resave: false,
	saveUninitialized: false,
	cookie: {
		secure: false,
		httpOnly: false,
		maxAge: 24 * 60 * 60 * 1000
	}
}));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const requireAuth = (req, res, next) => {
	if (req.session.userId) {
		next();
	} else {
		res.redirect('/login')
	}
}

app.get('/', (req, res) => {
	res.render('index', { user: req.session.userId ? true : false });
});

app.get('/register', (req, res) => {
	res.render('register');
});

app.post('/register', (req, res) => {
	let { username, password } = req.body;

	username = (username || "").trim();

	const USERNAME_RE = /^[A-Za-z0-9]{3,64}$/;

	if (!USERNAME_RE.test(username)) {
		console.log("Invalid Username Attempted:", username);
		return res.status(400).send("Username must be 3-64 characters, letters and numbers only.")
	}

	password = (password || "").toString();
	if (password.length < 1 || password.length > 256) {
		return res.status(400).send("Password Length is Invalid.");
	}

	db.run('INSERT INTO users (username, password) VALUES (?, ?)',
		[username, password],
		function (err) {
			if (err) {
				console.log("Error: ", err.message);
				return res.redirect('/register');
			}

			res.redirect('/login');
	});
});

app.get('/login', (req, res) => {
	res.render('login');
});

app.post('/login', (req, res) => {
	const { username, password } = req.body;

	db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
		if (err) {
			console.log("Error: ", err.message)
			return res.redirect('/login');
		}

		if (!user) {
			return res.redirect('/login');
		}

		if (password !== user.password) {
			return res.status(404).send('Invalid Password!')
		}

		req.session.userId = user.id;
		res.redirect('/dashboard');
	});
});

app.get('/dashboard', requireAuth, (req, res) => {
	db.get('SELECT * FROM users WHERE id = ?', [req.session.userId], (err, user) => {
		if (err) {
			return res.status(500).send('Error fetching user');
		}

		res.render('dashboard');
	});
});

app.post('/dashboard', requireAuth, (req, res) => {
	const { content } = req.body;

	db.get('SELECT MAX(user_note_id) as max_id FROM notes WHERE user_id = ?',
		[req.session.userId],
		(err, result) => {
			if (err) {
				return res.redirect('/dashboard');
			}

			const nextNoteId = (result.max_id || 0) + 1;

			db.run('INSERT INTO notes (user_note_id, content, user_id) VALUES (?, ?, ?)',
				[nextNoteId, content, req.session.userId],
				function(err) {
					if (err) {
						return res.redirect('/dashboard');
					}
					res.render('dashboard', { noteId: nextNoteId });
				});
		});
});

app.get('/view', requireAuth, (req, res) => {
	const noteId = (req.query.note ?? '').toString();

	db.get('SELECT * FROM users WHERE id = ?', 
		[req.session.userId], 
		(err, result) => {
			if (err) {
				res.status(500).send('Error fetching user');
			}

			res.render('view', { note_id: noteId, username: result.username })
	});
});

app.get('/api/notes/content/:noteId', requireAuth, (req, res) => {

	res.set('Cache-Control', 'no-store');

	const noteIdRaw = req.params.noteId;
	const noteId = Number.parseInt(noteIdRaw, 10);

	if (!Number.isInteger(noteId) || noteId < 1) {
		return res.status(400).json({ error: 'invalid note id' });
	}

	db.get('SELECT * FROM notes WHERE user_id = ? AND user_note_id = ?', 
		[req.session.userId, noteId],
		(err, notes) => {
			if (err) {
				return res.status(500).json({ error: 'db error' });
			}

			if (!notes) {
				return res.status(404).json({ error: 'Note not found' });
			}

			return res.json({ content: notes.content, note_id: notes.user_note_id })
		});
});

app.post('/api/notes/logs/:username', requireAuth, (req, res) => {

	res.set('Cache-Control', 'no-store');

	const username = req.params.username;
	const noteId = req.body.noteId;

	db.get(`SELECT users.id AS user_id,  
				users.username as username,
				notes.user_note_id AS user_note_id 
			FROM users 
			JOIN notes ON users.id = notes.user_id 
			WHERE users.id = ? AND users.username = ? 
			ORDER BY notes.user_note_id DESC 
			LIMIT 1`,
		[req.session.userId, username],
		(err, notes) => {
			if (err) {
				return res.status(500).json({ error: 'db error'});
			}

			if (!notes) {
				return res.status(404).json({ error: 'User not found' });
			}

			return res.json({ "User ID": notes.user_id, "Username": notes.username, "Notes Available": notes.user_note_id })
		});
});

app.get('/help', requireAuth, (req, res) => {
	res.render('help');
});

app.post('/help', requireAuth, (req, res) => {
	const username = (req.body?.username || '').toString().trim();

	return res.json({ "message": `We will get back to you ASAP, ${username} !` })
});

app.get('/report', requireAuth, (req, res) => {
	res.render('report');
});

app.post('/report', requireAuth, reportLimiter, (req, res) => {
  const url = (req.body?.input || '').toString().trim();

  db.get(
    "SELECT username, password FROM users WHERE id = ?",
    [req.session.userId],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: 'db not found' });
      }

      const credentials = {
      	username: result.username,
      	password: result.password
      };

      visit(url, credentials)
        .then(() => res.render('report', { report_done: true }))
        .catch((e) => res.status(400).send(`Error: ${e.message}`));
    }
  );
});

app.get('/logout', (req, res) => {
	req.session.destroy();
	res.redirect('/');
});

app.use((err, req, res, next) => {
	console.error('Unhandled error:', err);
    res.status(500).send('Something broke!');
}); 